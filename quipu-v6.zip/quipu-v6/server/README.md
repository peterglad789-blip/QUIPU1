# Yarbis AI server (Cloudflare Worker)

QUIPU is a static page on GitHub Pages, so it cannot keep a secret. This Worker holds the
Anthropic API key and forwards Yarbis chat requests. Without it, Yarbis runs as the
**Offline assistant** (labelled "no AI model connected") and still answers from the app's data
and calculations.

Request from the app: `POST {messages:[{role,content}…≤12], context:Q.context(), lang:"es"|"en"}`
Response: `{reply, model}` or `{error}` with an HTTP error status.

## What you need
- A Cloudflare account (free plan is enough).
- An Anthropic API key from https://console.anthropic.com (Settings → API keys). Billing must be set up.
- The origin of your site, with no path: `https://peterglad789-blip.github.io`

## Option A: dashboard (no terminal)
1. Cloudflare dashboard → **Workers & Pages** → **Create** → **Create Worker**. Name it `yarbis` → **Deploy**.
2. **Edit code**, delete the sample, paste all of `yarbis-worker.js`, **Deploy**.
3. Worker → **Settings** → **Variables and Secrets** → **Add**:
   - Type **Secret**, name `ANTHROPIC_API_KEY`, value: your key.
   - Type **Text**, name `ALLOWED_ORIGIN`, value: `https://peterglad789-blip.github.io`
   - Optional Text `MODEL` (default `claude-sonnet-5-5`), optional Text `MAX_TOKENS` (default 900).
   Save and deploy.
4. Copy the Worker URL shown on its page, e.g. `https://yarbis.<your-subdomain>.workers.dev`.

## Option B: wrangler (terminal)
```bash
npm install -g wrangler
wrangler login
mkdir yarbis && cd yarbis && cp /path/to/server/yarbis-worker.js worker.js
cat > wrangler.toml <<'EOF'
name = "yarbis"
main = "worker.js"
compatibility_date = "2026-11-01"
[vars]
ALLOWED_ORIGIN = "https://peterglad789-blip.github.io"
# MODEL = "claude-sonnet-5-5"
EOF
wrangler secret put ANTHROPIC_API_KEY     # paste the key when asked; it is never written to disk
wrangler deploy                           # prints the https://yarbis.<subdomain>.workers.dev URL
```

## Connect the app
1. Open QUIPU, press **Yarbis** (bottom right) → **Settings** tab.
2. Paste the Worker URL in **AI endpoint** → **Save and test**. A green "Connected" line confirms it;
   the header changes from "Offline assistant" to "Connected to an AI model".
3. The URL is stored in this browser only (`localStorage` key `quipu-cfg`, field `yarbisEndpoint`).
   To ship it for every visitor, set `const YARBIS_ENDPOINT='https://…'` at the top of `modules/yarbis.js`.
   The URL is not a secret; the key stays in Cloudflare.

## Test from a terminal
```bash
curl -s https://yarbis.<subdomain>.workers.dev \
  -H 'Origin: https://peterglad789-blip.github.io' -H 'Content-Type: application/json' \
  -d '{"messages":[{"role":"user","content":"¿Qué es el límite de regreso?"}],"context":{},"lang":"es"}'
```

## Safety limits built in
- CORS: only origins in `ALLOWED_ORIGIN` (comma-separated) get a response; `*` is refused.
- Body ≤ 48 KB, last 12 messages, 4,000 characters per message, 12,000 characters of context.
- Upstream errors are reduced to a short reason; the key and request are never echoed.
- For a public demo, also add a Cloudflare **Rate limiting rule** on the Worker route
  (for example 20 requests per minute per IP) and a monthly spend limit in the Anthropic console.

## Troubleshooting
| Symptom in Settings | Cause |
|---|---|
| `No response: HTTP 403` | `ALLOWED_ORIGIN` does not match the page origin exactly (no trailing slash, https). |
| `HTTP 500 … ANTHROPIC_API_KEY secret missing` | Secret not added, or added as plain text under another name. |
| `HTTP 502 Model request failed (authentication_error)` | Wrong or revoked key. |
| `HTTP 502 … (not_found_error)` | `MODEL` names a model your key cannot use; remove it to use the default. |
| `Failed to fetch` | Wrong URL, or an ad blocker; open the URL directly to check it answers "Use POST". |
