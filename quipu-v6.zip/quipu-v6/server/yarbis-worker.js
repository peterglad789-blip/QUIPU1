/**
 * Yarbis AI proxy: Cloudflare Worker.
 * The browser sends {messages, context, lang}; this Worker adds the system prompt and the
 * API key (kept as a Worker secret, never in the app) and calls the Anthropic Messages API.
 *
 * Environment:
 *   ANTHROPIC_API_KEY  (secret, required)
 *   ALLOWED_ORIGIN     (var, required) e.g. https://peterglad789-blip.github.io
 *                       comma-separate several origins; "*" is refused on purpose
 *   MODEL              (var, optional) default below
 *   MAX_TOKENS         (var, optional) default 900
 */
const DEFAULT_MODEL = 'claude-sonnet-5-5';
const MAX_BODY_BYTES = 48_000;      // whole request
const MAX_MESSAGES = 12;            // last turns kept
const MAX_MSG_CHARS = 4_000;        // per message
const MAX_CONTEXT_CHARS = 12_000;   // serialized app context

const SYSTEM = `You are Yarbis, the decision-support assistant inside QUIPU, a planning tool for a simulated crewed walk ("Marswalk") from a habitat in Jezero crater, Mars. The crew is Sebastián Palacios (EV1), Maximiliano Rutiaga (EV2) and Petr Gladskiy (IV, habitat).

Rules:
- You support decisions; you never replace mission control or the crew's judgement. For anything safety-critical, tell the crew to confirm with the app's panels and their procedures.
- Use the JSON "app context" for numbers: route, plan, consumables, thresholds (cfg), clock, selected point, status chips. Do not invent measurements, coordinates, sample names or data sources. If something is not in the context or in well-established public knowledge, say you don't know.
- Label every factual statement by type, inline, using these exact tags: [Verified data] (published mission data or the app's sourced layers), [Calculation] (arithmetic you did from context values; show the inputs), [Estimate] (models with assumptions such as metabolic rate), [Simulation] (what-if scenarios or simulated sensors).
- Distinguish measured, modelled, simulated and snapshot data. Space-weather arrivals from WSA-Enlil are modelled; RAD's 0.64 mSv/day is a Gale crater measurement used as a reference.
- When asked whether a destination is reachable, always include the return leg and the configured reserve; give GO, CAUTION or NO-GO with the reason, and use the thresholds in cfg.
- Reply in the user's language (lang: "es" Spanish (Mexico), "en" English). Be concise: short paragraphs or bullets, plain text, no headings, no emoji. Do not use the word "EVA"; say "walk" or "caminata".`;

function allowedOrigins(env) {
  return String(env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim().replace(/\/$/, '')).filter(Boolean);
}
function corsHeaders(origin, env) {
  const ok = origin && allowedOrigins(env).includes(origin);
  return ok ? {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  } : { 'Vary': 'Origin' };
}
function json(body, status, cors) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...cors } });
}

export default {
  async fetch(request, env) {
    const origin = (request.headers.get('Origin') || '').replace(/\/$/, '');
    const cors = corsHeaders(origin, env);
    const originOk = 'Access-Control-Allow-Origin' in cors;

    if (!allowedOrigins(env).length || allowedOrigins(env).includes('*'))
      return json({ error: 'Server misconfigured: set ALLOWED_ORIGIN to your site origin' }, 500, cors);
    if (request.method === 'OPTIONS') return new Response(null, { status: originOk ? 204 : 403, headers: cors });
    if (request.method !== 'POST') return json({ error: 'Use POST' }, 405, cors);
    if (!originOk) return json({ error: 'Origin not allowed' }, 403, cors);
    if (!env.ANTHROPIC_API_KEY) return json({ error: 'Server misconfigured: ANTHROPIC_API_KEY secret missing' }, 500, cors);

    const len = Number(request.headers.get('Content-Length') || 0);
    if (len > MAX_BODY_BYTES) return json({ error: 'Request too large' }, 413, cors);
    let raw;
    try { raw = await request.text(); } catch { return json({ error: 'Could not read body' }, 400, cors); }
    if (raw.length > MAX_BODY_BYTES) return json({ error: 'Request too large' }, 413, cors);

    let body;
    try { body = JSON.parse(raw); } catch { return json({ error: 'Body must be JSON' }, 400, cors); }
    const lang = body.lang === 'en' ? 'en' : 'es';

    // Sanitize conversation: alternate user/assistant, start with user, trimmed.
    const msgs = (Array.isArray(body.messages) ? body.messages : [])
      .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
      .slice(-MAX_MESSAGES)
      .map(m => ({ role: m.role, content: m.content.slice(0, MAX_MSG_CHARS) }));
    const merged = [];
    for (const m of msgs) {
      if (merged.length && merged[merged.length - 1].role === m.role) merged[merged.length - 1].content += '\n\n' + m.content;
      else merged.push({ ...m });
    }
    while (merged.length && merged[0].role !== 'user') merged.shift();
    if (!merged.length || merged[merged.length - 1].role !== 'user') return json({ error: 'Last message must be from the user' }, 400, cors);

    let ctx = '';
    try { ctx = JSON.stringify(body.context ?? {}); } catch { ctx = '{}'; }
    if (ctx.length > MAX_CONTEXT_CHARS) ctx = ctx.slice(0, MAX_CONTEXT_CHARS) + '…(truncated)';

    const model = env.MODEL || DEFAULT_MODEL;
    const system = `${SYSTEM}\n\nUser language: ${lang}.\nApp context (JSON, generated by the app at request time):\n${ctx}`;

    let r;
    try {
      r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model, max_tokens: Number(env.MAX_TOKENS) || 900, system, messages: merged }),
      });
    } catch (e) {
      return json({ error: 'Upstream unreachable' }, 502, cors);
    }
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      // Never forward the upstream body verbatim (could echo request details); give a short reason.
      const reason = data && data.error && data.error.type ? data.error.type : `status ${r.status}`;
      return json({ error: `Model request failed (${reason})` }, r.status === 429 ? 429 : 502, cors);
    }
    const reply = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
    return json({ reply, model: data.model || model }, 200, cors);
  },
};
